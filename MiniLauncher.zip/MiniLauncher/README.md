# Mini Launcher

A minimalist, fast home screen for Android car head units.

- Black, flat design: big clock and date, music controls, 6 pinned apps, and an "All apps" screen
- No animations, blur, live wallpaper or extra libraries, so it stays fast on weak hardware
- Music buttons control whichever player is active (Spotify, YouTube Music, the built-in player and so on)
- Works on Android 7 and newer, in landscape

## Build the APK (on a Windows or Mac PC)

1. Install **Android Studio** from developer.android.com/studio.
2. Unzip this folder, then in Android Studio choose **File → Open** and select the `MiniLauncher` folder.
3. Wait for "Gradle sync" to finish. If it asks to update Gradle or install an SDK, accept.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Click **locate** in the popup. The file is `app/build/outputs/apk/debug/app-debug.apk`.

## Install on the head unit

1. Copy `app-debug.apk` to a USB stick and plug it into the head unit.
2. Open the file manager on the unit and tap the APK.
   If it's blocked, allow "Install unknown apps" for the file manager.
3. Press the Home button. When asked, pick **Mini Launcher** and choose **Always**.
   If it doesn't ask, go to **Settings → Apps → Default apps → Home app**.

## Using it

- **Tap "Add app"** on an empty tile to pin an app.
- **Long-press a tile** to change or remove the app.
- **All apps**: tap to open an app, long-press to open App info (uninstall, force stop).

## If something goes wrong

- **Can't set it as Home**: some firmware locks the factory launcher. Look in the factory settings
  (often under Settings → Car settings, or a code such as 8888 or 1234) for a "Launcher" option.
- **Want the old launcher back**: Settings → Apps → Default apps → Home app, then pick the original.
- **Music buttons do nothing**: start the song once in the music app; the buttons control the last active player.
