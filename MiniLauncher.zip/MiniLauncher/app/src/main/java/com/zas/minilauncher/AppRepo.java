package com.zas.minilauncher;

import android.app.ActivityOptions;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Loads installed apps once and keeps them in memory, so opening "All apps" again is instant. */
final class AppRepo {

    static final class App {
        final ComponentName component;
        final String label;
        final Drawable icon;
        App(ComponentName c, String l, Drawable i) { component = c; label = l; icon = i; }
    }

    private static List<App> cache;

    private AppRepo() {}

    /** Call from a background thread. */
    static synchronized List<App> load(Context ctx, boolean force) {
        if (cache != null && !force) return cache;
        PackageManager pm = ctx.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos = pm.queryIntentActivities(main, 0);
        List<App> apps = new ArrayList<>(infos.size());
        String self = ctx.getPackageName();
        for (ResolveInfo ri : infos) {
            if (self.equals(ri.activityInfo.packageName)) continue;
            apps.add(new App(
                    new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name),
                    String.valueOf(ri.loadLabel(pm)),
                    ri.loadIcon(pm)));
        }
        Collections.sort(apps, (a, b) -> a.label.compareToIgnoreCase(b.label));
        cache = apps;
        return apps;
    }

    static synchronized void invalidate() { cache = null; }

    /** Opens an app with no transition animation (feels snappier on slow units). */
    static void launch(Context ctx, ComponentName cn) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(cn)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            Bundle opts = ActivityOptions.makeCustomAnimation(ctx, 0, 0).toBundle();
            ctx.startActivity(i, opts);
        } catch (Exception e) {
            Toast.makeText(ctx, "Can't open this app", Toast.LENGTH_SHORT).show();
        }
    }
}
