package com.zas.minilauncher;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * Two modes:
 *  - normal: list of all apps; tap opens, long-press opens App info (to uninstall / force stop)
 *  - picker: opened from a dock slot; tap returns that app to the home screen
 */
public class AppsActivity extends Activity {

    static final String EXTRA_SLOT = "slot";
    static final String EXTRA_COMPONENT = "component";

    private int slot = -1;
    private GridView grid;
    private TextView title;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        slot = getIntent().getIntExtra(EXTRA_SLOT, -1);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(getColor(R.color.bg));
        root.setPadding(dp(24), dp(16), dp(24), 0);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        title = new TextView(this);
        title.setTextColor(getColor(R.color.text));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        title.setText(slot >= 0 ? "Choose an app" : "Loading…");
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        if (slot >= 0) header.addView(textButton("Remove", v -> finishWith(null)));
        header.addView(textButton("Close", v -> close()));
        root.addView(header);

        grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(dp(130));
        grid.setVerticalSpacing(dp(8));
        grid.setHorizontalSpacing(dp(8));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        grid.setVerticalScrollBarEnabled(false);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, 0, 1f);
        gp.topMargin = dp(12);
        root.addView(grid, gp);

        setContentView(root);

        // Load off the main thread so the screen appears immediately.
        new Thread(() -> {
            List<AppRepo.App> apps = AppRepo.load(getApplicationContext(), false);
            runOnUiThread(() -> show(apps));
        }).start();
    }

    private void show(List<AppRepo.App> apps) {
        if (isFinishing()) return;
        if (slot < 0) title.setText("All apps");
        grid.setAdapter(new Adapter(apps));
        grid.setOnItemClickListener((p, v, pos, id) -> {
            AppRepo.App a = apps.get(pos);
            if (slot >= 0) finishWith(a.component.flattenToString());
            else { AppRepo.launch(this, a.component); close(); }
        });
        grid.setOnItemLongClickListener((p, v, pos, id) -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + apps.get(pos).component.getPackageName()));
            startActivity(i);
            return true;
        });
    }

    private void finishWith(String component) {
        Intent r = new Intent().putExtra(EXTRA_SLOT, slot);
        if (component != null) r.putExtra(EXTRA_COMPONENT, component);
        setResult(RESULT_OK, r);
        close();
    }

    private void close() {
        finish();
        overridePendingTransition(0, 0);
    }

    @Override
    public void onBackPressed() { close(); }

    private TextView textButton(String text, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(getColor(R.color.accent));
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        b.setPadding(dp(20), dp(12), dp(20), dp(12));
        b.setOnClickListener(l);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    /** Recycles tile views (ViewHolder pattern) so scrolling stays smooth on weak hardware. */
    private final class Adapter extends BaseAdapter {
        private final List<AppRepo.App> apps;
        Adapter(List<AppRepo.App> apps) { this.apps = apps; }

        @Override public int getCount() { return apps.size(); }
        @Override public Object getItem(int i) { return apps.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            LinearLayout tile = (LinearLayout) convert;
            if (tile == null) {
                tile = new LinearLayout(AppsActivity.this);
                tile.setOrientation(LinearLayout.VERTICAL);
                tile.setGravity(Gravity.CENTER);
                tile.setBackgroundResource(R.drawable.tile);
                tile.setPadding(dp(8), dp(16), dp(8), dp(14));
                tile.setLayoutParams(new GridView.LayoutParams(-1, dp(130)));

                ImageView icon = new ImageView(AppsActivity.this);
                tile.addView(icon, new LinearLayout.LayoutParams(dp(56), dp(56)));

                TextView label = new TextView(AppsActivity.this);
                label.setTextColor(getColor(R.color.text));
                label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                label.setSingleLine(true);
                label.setGravity(Gravity.CENTER);
                label.setPadding(0, dp(10), 0, 0);
                tile.addView(label, new LinearLayout.LayoutParams(-1, -2));
            }
            AppRepo.App a = apps.get(pos);
            ((ImageView) tile.getChildAt(0)).setImageDrawable(a.icon);
            ((TextView) tile.getChildAt(1)).setText(a.label);
            return tile;
        }
    }
}
