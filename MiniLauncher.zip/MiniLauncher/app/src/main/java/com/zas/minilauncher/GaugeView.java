package com.zas.minilauncher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/**
 * Futuristic arc speedometer. Draws only when the speed changes (about once a second),
 * so it costs almost nothing. No bitmaps, no animation loop.
 */
public class GaugeView extends View {

    private static final float START = 135f, SWEEP = 270f, MAX = 180f;

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint unit = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private float speed = -1;   // -1 = no GPS fix yet
    private final float d;

    public GaugeView(Context c, AttributeSet a) {
        super(c, a);
        d = getResources().getDisplayMetrics().density;
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setColor(0x1A22D3EE);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        tick.setColor(0x5522D3EE);
        tick.setStrokeWidth(1.5f * d);
        num.setColor(0xFFEAF6FF);
        num.setTextAlign(Paint.Align.CENTER);
        num.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
        unit.setColor(0xFF22D3EE);
        unit.setTextAlign(Paint.Align.CENTER);
        unit.setLetterSpacing(0.2f);
        unit.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    }

    /** Speed in km/h, or a negative value when there is no GPS signal. */
    public void setSpeed(float kmh) {
        float v = kmh < 0 ? -1 : Math.round(kmh);
        if (v == speed) return;          // skip redraw when nothing changed
        speed = v;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float size = Math.min(w, h);
        float stroke = size * 0.07f;
        float pad = stroke / 2f + 2 * d;
        float cx = w / 2f, cy = h / 2f + size * 0.06f;
        box.set(cx - size / 2f + pad, cy - size / 2f + pad, cx + size / 2f - pad, cy + size / 2f - pad);
        track.setStrokeWidth(stroke);
        arc.setStrokeWidth(stroke);
        SweepGradient g = new SweepGradient(cx, cy,
                new int[]{0xFF22D3EE, 0xFF8B5CF6, 0xFFEC4899, 0xFF22D3EE},
                new float[]{0f, 0.45f, 0.75f, 1f});
        Matrix m = new Matrix();
        m.setRotate(START - 5, cx, cy);
        g.setLocalMatrix(m);
        arc.setShader(g);
        num.setTextSize(size * 0.30f);
        unit.setTextSize(size * 0.075f);
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = box.centerX(), cy = box.centerY(), r = box.width() / 2f;

        c.drawArc(box, START, SWEEP, false, track);

        // Tick marks every 20 km/h, just inside the arc
        for (int i = 0; i <= 9; i++) {
            double ang = Math.toRadians(START + SWEEP * i / 9f);
            float r1 = r - track.getStrokeWidth() * 0.9f, r2 = r1 - 6 * d;
            c.drawLine(cx + (float) Math.cos(ang) * r1, cy + (float) Math.sin(ang) * r1,
                    cx + (float) Math.cos(ang) * r2, cy + (float) Math.sin(ang) * r2, tick);
        }

        if (speed > 0) c.drawArc(box, START, SWEEP * Math.min(speed, MAX) / MAX, false, arc);

        String txt = speed < 0 ? "--" : String.valueOf((int) speed);
        c.drawText(txt, cx, cy + num.getTextSize() * 0.32f, num);
        c.drawText(speed < 0 ? "NO GPS" : "KM/H", cx, cy + num.getTextSize() * 0.32f + unit.getTextSize() * 2.0f, unit);
    }
}
