package com.zas.minilauncher;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.Manifest;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.provider.Settings;
import android.widget.ImageButton;
import java.util.List;

public class MainActivity extends Activity {

    static final int GRID_SLOTS = 4;   // slots 0..3 : icon row (with labels)
    static final int DOCK_SLOTS = 4;   // slots 4..7 : dock (icons only)
    static final int PHONE_SLOT = 99;  // Phone Connect card (CarPlay / Android Auto app)

    /** Words found in the names of common CarPlay / Android Auto apps on Android head units. */
    private static final String[] PHONE_APP_WORDS = {
            "carplay", "android auto", "zlink", "autokit", "carlink", "carbit",
            "tlink", "phonelink", "phone link", "easyconnect", "mirror"};
    static final String PREFS = "dock";
    private static final int REQ_PICK = 1;

    private GridLayout grid;
    private LinearLayout dockSlots;
    private SharedPreferences prefs;

    // GPS speedometer
    private static final int REQ_LOCATION = 2;
    private GaugeView gauge;
    private LocationManager lm;
    private boolean askedLocation;

    // Live music info
    private MediaSessionManager msm;
    private MediaController controller;
    private boolean mediaAccess;
    private TextView songTitle, songArtist;
    private ImageButton btnPlay;

    /** Refresh icons when apps are installed or removed. */
    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            AppRepo.invalidate();
            buildAll();
            new Thread(() -> {
                AppRepo.load(getApplicationContext(), true);
                runOnUiThread(MainActivity.this::updatePhoneCard);
            }).start();
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        grid = findViewById(R.id.grid);
        dockSlots = findViewById(R.id.dockSlots);

        gauge = findViewById(R.id.gauge);
        songTitle = findViewById(R.id.songTitle);
        songArtist = findViewById(R.id.songArtist);
        btnPlay = findViewById(R.id.btnPlay);

        findViewById(R.id.btnPrev).setOnClickListener(v -> {
            if (controller != null) controller.getTransportControls().skipToPrevious();
            else mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS);
        });
        btnPlay.setOnClickListener(v -> {
            if (controller == null) { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return; }
            if (isPlaying()) controller.getTransportControls().pause();
            else controller.getTransportControls().play();
        });
        findViewById(R.id.btnNext).setOnClickListener(v -> {
            if (controller != null) controller.getTransportControls().skipToNext();
            else mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT);
        });
        findViewById(R.id.musicCard).setOnClickListener(v -> openMusicApp());
        findViewById(R.id.btnAllApps).setOnClickListener(v -> {
            startActivity(new Intent(this, AppsActivity.class));
            overridePendingTransition(0, 0);
        });

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        View phoneCard = findViewById(R.id.phoneCard);
        phoneCard.setOnClickListener(v -> openPhoneApp());
        phoneCard.setOnLongClickListener(v -> { pick(PHONE_SLOT); return true; });

        buildAll();
        // Load the app list in the background: makes "All apps" instant and finds the CarPlay app.
        new Thread(() -> {
            AppRepo.load(getApplicationContext(), false);
            runOnUiThread(this::updatePhoneCard);
        }).start();
    }

    // Sensors only run while the home screen is visible: zero cost while you use Waze or CarPlay.
    @Override
    protected void onResume() {
        super.onResume();
        startGps();
        startMedia();
    }

    @Override
    protected void onPause() {
        stopGps();
        stopMedia();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(pkgReceiver);
        super.onDestroy();
    }

    /** A launcher should never close itself on Back. */
    @Override
    public void onBackPressed() { }

    // ---------- Music controls (works with any player: Spotify, YouTube Music, built-in) ----------

    private void mediaKey(int code) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        long now = SystemClock.uptimeMillis();
        am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0));
        am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0));
    }

    // ---------- GPS speedometer ----------

    private final LocationListener gpsListener = new LocationListener() {
        @Override public void onLocationChanged(Location l) {
            if (l.hasSpeed()) gauge.setSpeed(l.getSpeed() * 3.6f);
        }
        // All four methods implemented: required on Android 10 and older.
        @Override public void onStatusChanged(String p, int s, Bundle b) { }
        @Override public void onProviderEnabled(String p) { }
        @Override public void onProviderDisabled(String p) { gauge.setSpeed(-1); }
    };

    private void startGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            gauge.setSpeed(-1);
            if (!askedLocation) {
                askedLocation = true;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            }
            return;
        }
        try {
            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, gpsListener, getMainLooper());
        } catch (Exception e) {
            gauge.setSpeed(-1);   // no GPS chip or provider disabled
        }
    }

    private void stopGps() {
        if (lm != null) {
            try { lm.removeUpdates(gpsListener); } catch (Exception ignored) { }
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_LOCATION) startGps();
    }

    // ---------- Live music info (song title, artist, real play/pause state) ----------

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener =
            this::pickController;

    private final MediaController.Callback mediaCallback = new MediaController.Callback() {
        @Override public void onMetadataChanged(MediaMetadata m) { updateMedia(); }
        @Override public void onPlaybackStateChanged(PlaybackState s) { updateMedia(); }
        @Override public void onSessionDestroyed() { pickController(null); }
    };

    private void startMedia() {
        ComponentName listener = new ComponentName(this, MediaListener.class);
        try {
            msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
            List<MediaController> list = msm.getActiveSessions(listener);
            msm.addOnActiveSessionsChangedListener(sessionsListener, listener);
            mediaAccess = true;
            pickController(list);
        } catch (SecurityException e) {
            // User hasn't enabled Notification access yet
            mediaAccess = false;
            songTitle.setText("Now Playing");
            songArtist.setText("Tap here to show song names");
        }
    }

    private void stopMedia() {
        if (msm != null) {
            try { msm.removeOnActiveSessionsChangedListener(sessionsListener); } catch (Exception ignored) { }
        }
        if (controller != null) controller.unregisterCallback(mediaCallback);
        controller = null;
    }

    /** Prefer the player that is currently playing; otherwise the most recent one. */
    private void pickController(List<MediaController> list) {
        if (list == null && msm != null) {
            try { list = msm.getActiveSessions(new ComponentName(this, MediaListener.class)); }
            catch (SecurityException e) { list = null; }
        }
        MediaController best = null;
        if (list != null) {
            for (MediaController c : list) {
                PlaybackState st = c.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PLAYING) { best = c; break; }
            }
            if (best == null && !list.isEmpty()) best = list.get(0);
        }
        if (controller != null) controller.unregisterCallback(mediaCallback);
        controller = best;
        if (controller != null) controller.registerCallback(mediaCallback);
        updateMedia();
    }

    private boolean isPlaying() {
        PlaybackState st = controller == null ? null : controller.getPlaybackState();
        return st != null && st.getState() == PlaybackState.STATE_PLAYING;
    }

    private void updateMedia() {
        String title = null, artist = null;
        if (controller != null && controller.getMetadata() != null) {
            MediaMetadata m = controller.getMetadata();
            title = m.getString(MediaMetadata.METADATA_KEY_TITLE);
            artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST);
        }
        if (title == null || title.isEmpty()) {
            songTitle.setText("Now Playing");
            songArtist.setText(controller == null ? "Nothing playing" : "Unknown track");
        } else {
            songTitle.setText(title);
            songArtist.setText(artist == null ? "" : artist);
        }
        btnPlay.setImageResource(isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);
    }

    private void openMusicApp() {
        if (!mediaAccess) {
            try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
            catch (Exception ignored) { }
            return;
        }
        if (controller == null) return;
        Intent i = getPackageManager().getLaunchIntentForPackage(controller.getPackageName());
        if (i != null) {
            startActivity(i);
            overridePendingTransition(0, 0);
        }
    }

    // ---------- Pinned apps. Tap = open, long-press = change ----------

    private void buildAll() {
        grid.removeAllViews();
        for (int i = 0; i < GRID_SLOTS; i++) {
            View tile = makeSlot(i, 72, true);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(0, 1f), GridLayout.spec(i, 1f));
            lp.width = 0;
            lp.height = 0;
            int g = dp(4);
            lp.setMargins(g, g, g, g);
            grid.addView(tile, lp);
        }

        dockSlots.removeAllViews();
        for (int i = 0; i < DOCK_SLOTS; i++) {
            View tile = makeSlot(GRID_SLOTS + i, 56, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(72), ViewGroup.LayoutParams.MATCH_PARENT);
            lp.setMargins(dp(2), dp(6), dp(2), dp(6));
            dockSlots.addView(tile, lp);
        }
    }

    private View makeSlot(int slot, int iconDp, boolean withLabel) {
        PackageManager pm = getPackageManager();
        ComponentName cn = ComponentName.unflattenFromString(prefs.getString("slot_" + slot, ""));

        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setBackgroundResource(R.drawable.tile);

        ImageView icon = new ImageView(this);
        tile.addView(icon, new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)));

        TextView label = null;
        if (withLabel) {
            label = new TextView(this);
            label.setTextColor(getColor(R.color.text));
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            label.setSingleLine(true);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setGravity(Gravity.CENTER);
            label.setPadding(dp(6), dp(10), dp(6), 0);
            tile.addView(label, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        boolean ok = false;
        if (cn != null) {
            try {
                icon.setImageDrawable(pm.getActivityIcon(cn));
                if (label != null) label.setText(pm.getActivityInfo(cn, 0).loadLabel(pm));
                ok = true;
            } catch (PackageManager.NameNotFoundException ignored) { }
        }

        if (ok) {
            final ComponentName target = cn;
            tile.setOnClickListener(v -> AppRepo.launch(this, target));
        } else {
            icon.setBackgroundResource(R.drawable.empty_slot);
            icon.setImageResource(R.drawable.ic_add);
            icon.setScaleType(ImageView.ScaleType.CENTER);
            if (label != null) {
                label.setText("Add");
                label.setTextColor(getColor(R.color.text_dim));
            }
            tile.setOnClickListener(v -> pick(slot));
        }
        tile.setOnLongClickListener(v -> { pick(slot); return true; });
        return tile;
    }

    // ---------- Phone Connect: opens the head unit's CarPlay / Android Auto app ----------

    /** The app chosen by the user, or else the first installed app whose name matches. */
    private ComponentName phoneApp() {
        ComponentName chosen = ComponentName.unflattenFromString(prefs.getString("slot_" + PHONE_SLOT, ""));
        if (chosen != null) return chosen;
        java.util.List<AppRepo.App> apps = AppRepo.cached();
        if (apps == null) return null;
        for (AppRepo.App a : apps) {
            String name = a.label.toLowerCase(java.util.Locale.ROOT);
            String pkg = a.component.getPackageName().toLowerCase(java.util.Locale.ROOT);
            for (String w : PHONE_APP_WORDS) {
                if (name.contains(w) || pkg.contains(w.replace(" ", ""))) return a.component;
            }
        }
        return null;
    }

    private void updatePhoneCard() {
        TextView t = findViewById(R.id.phoneApp);
        ComponentName cn = phoneApp();
        if (cn == null) { t.setText("Tap to choose your CarPlay app"); return; }
        try {
            PackageManager pm = getPackageManager();
            t.setText("Opens " + pm.getActivityInfo(cn, 0).loadLabel(pm));
        } catch (PackageManager.NameNotFoundException e) {
            t.setText("Tap to choose your CarPlay app");
        }
    }

    private void openPhoneApp() {
        ComponentName cn = phoneApp();
        if (cn == null) pick(PHONE_SLOT);
        else AppRepo.launch(this, cn);
    }

    private void pick(int slot) {
        Intent i = new Intent(this, AppsActivity.class).putExtra(AppsActivity.EXTRA_SLOT, slot);
        startActivityForResult(i, REQ_PICK);
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        int slot = data.getIntExtra(AppsActivity.EXTRA_SLOT, -1);
        String comp = data.getStringExtra(AppsActivity.EXTRA_COMPONENT);
        if (slot < 0) return;
        if (comp == null) prefs.edit().remove("slot_" + slot).apply();      // "Remove" chosen
        else prefs.edit().putString("slot_" + slot, comp).apply();
        if (slot == PHONE_SLOT) updatePhoneCard();
        else buildAll();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
