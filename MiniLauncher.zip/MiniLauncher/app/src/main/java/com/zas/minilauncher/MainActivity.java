package com.zas.minilauncher;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    static final int GRID_SLOTS = 8;   // slots 0..7  : icon grid (with labels)
    static final int DOCK_SLOTS = 4;   // slots 8..11 : dock (icons only)
    static final String PREFS = "dock";
    private static final int REQ_PICK = 1;

    private GridLayout grid;
    private LinearLayout dockSlots;
    private SharedPreferences prefs;

    /** Refresh icons when apps are installed or removed. */
    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            AppRepo.invalidate();
            buildAll();
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        grid = findViewById(R.id.grid);
        dockSlots = findViewById(R.id.dockSlots);

        findViewById(R.id.btnPrev).setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS));
        findViewById(R.id.btnPlay).setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
        findViewById(R.id.btnNext).setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT));
        findViewById(R.id.btnAllApps).setOnClickListener(v -> {
            startActivity(new Intent(this, AppsActivity.class));
            overridePendingTransition(0, 0);
        });

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        buildAll();
        // Warm up the app list in the background so "All apps" opens instantly.
        new Thread(() -> AppRepo.load(getApplicationContext(), false)).start();
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(pkgReceiver);
        super.onDestroy();
    }

    /** A launcher should never close itself on Back. */
    @Override
    public void onBackPressed() { }

    // ---------- Music controls (works with any player: Spotify, YouTube Music, built-in) ----------

    private void mediaKey(int code) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        long now = SystemClock.uptimeMillis();
        am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0));
        am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0));
    }

    // ---------- Pinned apps. Tap = open, long-press = change ----------

    private void buildAll() {
        grid.removeAllViews();
        for (int i = 0; i < GRID_SLOTS; i++) {
            View tile = makeSlot(i, 72, true);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(i / 4, 1f), GridLayout.spec(i % 4, 1f));
            lp.width = 0;
            lp.height = 0;
            int g = dp(4);
            lp.setMargins(g, g, g, g);
            grid.addView(tile, lp);
        }

        dockSlots.removeAllViews();
        for (int i = 0; i < DOCK_SLOTS; i++) {
            View tile = makeSlot(GRID_SLOTS + i, 56, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(72), ViewGroup.LayoutParams.MATCH_PARENT);
            lp.setMargins(dp(2), dp(6), dp(2), dp(6));
            dockSlots.addView(tile, lp);
        }
    }

    private View makeSlot(int slot, int iconDp, boolean withLabel) {
        PackageManager pm = getPackageManager();
        ComponentName cn = ComponentName.unflattenFromString(prefs.getString("slot_" + slot, ""));

        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setBackgroundResource(R.drawable.tile);

        ImageView icon = new ImageView(this);
        tile.addView(icon, new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)));

        TextView label = null;
        if (withLabel) {
            label = new TextView(this);
            label.setTextColor(getColor(R.color.text));
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            label.setSingleLine(true);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setGravity(Gravity.CENTER);
            label.setPadding(dp(6), dp(10), dp(6), 0);
            tile.addView(label, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        boolean ok = false;
        if (cn != null) {
            try {
                icon.setImageDrawable(pm.getActivityIcon(cn));
                if (label != null) label.setText(pm.getActivityInfo(cn, 0).loadLabel(pm));
                ok = true;
            } catch (PackageManager.NameNotFoundException ignored) { }
        }

        if (ok) {
            final ComponentName target = cn;
            tile.setOnClickListener(v -> AppRepo.launch(this, target));
        } else {
            icon.setBackgroundResource(R.drawable.empty_slot);
            icon.setImageResource(R.drawable.ic_add);
            icon.setScaleType(ImageView.ScaleType.CENTER);
            if (label != null) {
                label.setText("Add");
                label.setTextColor(getColor(R.color.text_dim));
            }
            tile.setOnClickListener(v -> pick(slot));
        }
        tile.setOnLongClickListener(v -> { pick(slot); return true; });
        return tile;
    }

    private void pick(int slot) {
        Intent i = new Intent(this, AppsActivity.class).putExtra(AppsActivity.EXTRA_SLOT, slot);
        startActivityForResult(i, REQ_PICK);
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        int slot = data.getIntExtra(AppsActivity.EXTRA_SLOT, -1);
        String comp = data.getStringExtra(AppsActivity.EXTRA_COMPONENT);
        if (slot < 0) return;
        if (comp == null) prefs.edit().remove("slot_" + slot).apply();      // "Remove" chosen
        else prefs.edit().putString("slot_" + slot, comp).apply();
        buildAll();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
