package com.zas.minilauncher;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    static final int SLOTS = 6;
    static final String PREFS = "dock";
    private static final int REQ_PICK = 1;

    private GridLayout dock;
    private SharedPreferences prefs;

    /** Refresh the dock when apps are installed or removed. */
    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            AppRepo.invalidate();
            buildDock();
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        dock = findViewById(R.id.dock);

        findViewById(R.id.btnPrev).setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS));
        findViewById(R.id.btnPlay).setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
        findViewById(R.id.btnNext).setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT));
        findViewById(R.id.btnAllApps).setOnClickListener(v -> {
            startActivity(new Intent(this, AppsActivity.class));
            overridePendingTransition(0, 0);
        });

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        buildDock();
        // Warm up the app list in the background so "All apps" opens instantly.
        new Thread(() -> AppRepo.load(getApplicationContext(), false)).start();
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(pkgReceiver);
        super.onDestroy();
    }

    /** A launcher should never close itself on Back. */
    @Override
    public void onBackPressed() { }

    // ---------- Music controls (works with any player: Spotify, YouTube Music, built-in) ----------

    private void mediaKey(int code) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        long now = SystemClock.uptimeMillis();
        am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0));
        am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0));
    }

    // ---------- Dock: 6 pinned apps. Tap = open, long-press = change ----------

    private void buildDock() {
        dock.removeAllViews();
        PackageManager pm = getPackageManager();
        int gap = dp(8);

        for (int i = 0; i < SLOTS; i++) {
            final int slot = i;
            ComponentName cn = ComponentName.unflattenFromString(prefs.getString("slot_" + i, ""));

            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setBackgroundResource(R.drawable.tile);

            ImageView icon = new ImageView(this);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(64), dp(64));
            tile.addView(icon, ip);

            TextView label = new TextView(this);
            label.setTextColor(getColor(R.color.text));
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
            label.setSingleLine(true);
            label.setPadding(dp(8), dp(10), dp(8), 0);
            tile.addView(label);

            boolean ok = false;
            if (cn != null) {
                try {
                    icon.setImageDrawable(pm.getActivityIcon(cn));
                    label.setText(pm.getActivityInfo(cn, 0).loadLabel(pm));
                    ok = true;
                } catch (PackageManager.NameNotFoundException ignored) { }
            }
            if (ok) {
                final ComponentName target = cn;
                tile.setOnClickListener(v -> AppRepo.launch(this, target));
            } else {
                icon.setImageResource(R.drawable.ic_add);
                label.setText("Add app");
                label.setTextColor(getColor(R.color.text_dim));
                tile.setOnClickListener(v -> pick(slot));
            }
            tile.setOnLongClickListener(v -> { pick(slot); return true; });

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(i / 3, 1f), GridLayout.spec(i % 3, 1f));
            lp.width = 0;
            lp.height = 0;
            lp.setMargins(gap, gap, gap, gap);
            dock.addView(tile, lp);
        }
    }

    private void pick(int slot) {
        Intent i = new Intent(this, AppsActivity.class).putExtra(AppsActivity.EXTRA_SLOT, slot);
        startActivityForResult(i, REQ_PICK);
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        int slot = data.getIntExtra(AppsActivity.EXTRA_SLOT, -1);
        String comp = data.getStringExtra(AppsActivity.EXTRA_COMPONENT);
        if (slot < 0) return;
        if (comp == null) prefs.edit().remove("slot_" + slot).apply();      // "Remove" chosen
        else prefs.edit().putString("slot_" + slot, comp).apply();
        buildDock();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
