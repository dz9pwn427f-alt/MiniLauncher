package com.zas.minilauncher;

import android.service.notification.NotificationListenerService;

/**
 * Empty on purpose. Android only lets an app read "what's playing" (song title, artist,
 * play/pause state) if the user enables this listener under Notification access.
 * We never read or store notifications.
 */
public class MediaListener extends NotificationListenerService { }
